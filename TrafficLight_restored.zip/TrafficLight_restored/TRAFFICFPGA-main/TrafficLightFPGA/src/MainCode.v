// MainCode.v – Top-level traffic light control
module MainCode (
    input  wire       Clk_50MHz,
    input  wire       rst_n,
    output wire [6:0] HexH,
    output wire [6:0] HexL,
    output wire       Green,
    output wire       Red,
    output wire       Amber
);
    wire       CLK_1Hz;
    wire [5:0] ControlSignal;
    wire [3:0] Count;
    
    // Declaring the internal wires that were missing
    wire [6:0] HexH_internal;
    wire [6:0] HexL_internal;

    ClockDivider cd (
        .CLK_50MHz (Clk_50MHz),
        .rst_n     (rst_n),
        .CLK_1Hz   (CLK_1Hz)
    );

    CoreLogic cl (
        .CLK           (CLK_1Hz),
        .rst_n         (rst_n),
        .ControlSignal (ControlSignal)
    );

    Decoder d (
        .ControlSignal (ControlSignal),
        .Count         (Count),
        .Green         (Green),
        .Red           (Red),
        .Amber         (Amber)
    );

    SevenSegDisplay ssd (
        .Count     (Count),
        .SevenSegH (HexH_internal),
        .SevenSegL (HexL_internal)
    );

    // DE10-Lite 7-segment displays are Active-Low
    // We invert them here inside the module
    assign HexL = ~HexL_internal; 
    assign HexH = ~HexH_internal;

endmodule